Please use pip to install the required dependencies.

Below command will install opencv-python and numpy.
pip install -r requirements.txt

The folder model contains xml files of pretrained models with various thresholds to detect car and pedestrians.